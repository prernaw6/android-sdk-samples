package com.sensorberg.sdk.demo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.sensorberg.sdk.cluster.BeaconCluster;
import com.sensorberg.sdk.presenter.Presentation;
import com.sensorberg.sdk.presenter.PresentationConfiguration;
import com.sensorberg.sdk.presenter.Presenter;
import com.sensorberg.sdk.presenter.PresenterListener;
import com.sensorberg.sdk.resolver.BeaconEvent;
import com.sensorberg.sdk.resolver.Resolution;
import com.sensorberg.sdk.resolver.ResolutionConfiguration;
import com.sensorberg.sdk.resolver.Resolver;
import com.sensorberg.sdk.resolver.ResolverListener;
import com.sensorberg.sdk.scanner.Scan;
import com.sensorberg.sdk.scanner.ScanConfiguration;
import com.sensorberg.sdk.scanner.ScanEvent;
import com.sensorberg.sdk.scanner.ScanEventType;
import com.sensorberg.sdk.scanner.Scanner;
import com.sensorberg.sdk.scanner.ScannerListener;

@SuppressWarnings("javadoc")
public class DemoActivity extends Activity implements ScannerListener, ResolverListener, PresenterListener
{
	Scanner		scanner		= Scanner.getInstance();
	Resolver	resolver	= Resolver.getInstance();
	Presenter	presenter	= Presenter.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(new TextView(this));
	}

	@Override
	protected void onPause()
	{
		//
		// Unregister listener and stop all activity
		//
		presenter.removePresenterListener(this);
		presenter.stopAllPresentations();
		resolver.removeResolverListener(this);
		resolver.stopAllResolutions();
		scanner.removeScannerListener(this);
		scanner.stopAllScans();
		super.onPause();
	}

	public void onPresentationFailed(Presentation presentation, Throwable cause)
	{
		//
		// We don't need this
		//
	}

	public void onPresentationFinished(Presentation presentation, BeaconEvent beaconEvent)
	{
		//
		// We don't need this
		//
	}

	public void onResolutionFailed(Resolution resolution, final Throwable throwable)
	{
		runOnUiThread(new Runnable()
		{
			public void run()
			{
				//
				// Show event in Toast
				//
				Toast.makeText(DemoActivity.this, "Resolution failed" + throwable.getLocalizedMessage(), Toast.LENGTH_LONG).show();
			}
		});
	}

	public void onResolutionFinished(Resolution resolution, final BeaconEvent beaconEvent)
	{
		runOnUiThread(new Runnable()
		{
			public void run()
			{
				PresentationConfiguration presentationConfiguration = new PresentationConfiguration();
				presentationConfiguration.setBeaconEvent(beaconEvent);
				presentationConfiguration.setNotificationIcon(R.drawable.ic_launcher);
				presentationConfiguration.setNotificationId(1);
                Presentation presentation = presenter.createPresentation(presentationConfiguration);
                presentation.start();
			}
		});
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		//
		// Finish if Bluetooth is not supported and active
		//
		if(!scanner.isBluetoothSupported() || !scanner.isBluetoothActive())
		{
            Toast.makeText(this, "BTLE not supported and active.", Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		//
		// Register listener
		//
		scanner.addScannerListener(this);
		resolver.addResolverListener(this);
		presenter.addPresenterListener(this);
		//
		// Create new ScanConfiguration
		//
		ScanConfiguration scanConfiguration = new ScanConfiguration();
		scanConfiguration.setBeaconCluster(BeaconCluster.SENSORBERG_CLUSTER);
		scanConfiguration.setEventMask(ScanEventType.ENTRY.getMask());
		scanConfiguration.setScanDuration(Long.MAX_VALUE);
		//
		// Create and start new Scan
		//
		Scan scan = scanner.createScan(scanConfiguration);
		scan.start();
	}

	public void onScanEventDetected(Scan scan, final ScanEvent scanEvent)
	{
		//
		// Start resolution of the detected ScanEvent
		//
		ResolutionConfiguration resolutionConfiguration = new ResolutionConfiguration();
		resolutionConfiguration.setScanEvent(scanEvent);
		Resolution resolution = resolver.createResolution(resolutionConfiguration);
		resolver.startResolution(resolution);
		runOnUiThread(new Runnable()
		{
			public void run()
			{
				//
				// Show event in Toast
				//
				Toast.makeText(DemoActivity.this, "scan detected, starting resolution:" +
                        scanEvent.getEventMask() + " " +
                        scanEvent.getBeaconId().toString(), Toast.LENGTH_LONG).show();
			}
		});
	}

	public void onScanFailed(Scan scan, Throwable throwable)
	{
		runOnUiThread(new Runnable()
		{
			public void run()
			{
				//
				// Show event in Toast
				//
				Toast.makeText(DemoActivity.this, "Scan failed", Toast.LENGTH_LONG).show();
			}
		});
	}

	public void onScanFinished(Scan scan)
	{
		//
		// We don't need this
		//
	}

	public void onScanStarted(Scan scan)
	{
		//
		// We don't need this
		//
	}
}
