package com.sensorberg.sdk.demo;

import android.app.Application;

import com.sensorberg.sdk.presenter.Presenter;
import com.sensorberg.sdk.presenter.PresenterConfiguration;
import com.sensorberg.sdk.resolver.Resolver;
import com.sensorberg.sdk.resolver.ResolverConfiguration;
import com.sensorberg.sdk.scanner.Scanner;
import com.sensorberg.sdk.scanner.ScannerConfiguration;

@SuppressWarnings("javadoc")
public class DemoApplication extends Application
{
	@Override
	public void onCreate()
	{
		super.onCreate();
		//
		// Configure the Scanner; the Application context set in the configuration will be kept for the lifetime of the application.
		// The Scanner will be available via Scanner.getInstance() for the lifetime of the application.
		//
		ScannerConfiguration scannerConfiguration = new ScannerConfiguration();
		scannerConfiguration.setApplication(this);
		scannerConfiguration.setExitEventDelay(15000);
		Scanner.getInstance(scannerConfiguration);
		//
		// Configure the Resolver; the Application context set in the configuration will be kept for the lifetime of the application.
		// The Resolver will be available via Resolver.getInstance() for the lifetime of the application.
		//
		ResolverConfiguration resolverConfiguration = new ResolverConfiguration();
		resolverConfiguration.setApiToken("1234567890");
		resolverConfiguration.setApplication(this);
		Resolver.getInstance(resolverConfiguration);
		//
		// Configure the Presenter; the Application context set in the configuration will be kept for the lifetime of the application.
		// The Presenter will be available via Presenter.getInstance() for the lifetime of the application.
		//
		PresenterConfiguration presenterConfiguration = new PresenterConfiguration();
		presenterConfiguration.setApplication(this);
		Presenter.getInstance(presenterConfiguration);
	}
}
